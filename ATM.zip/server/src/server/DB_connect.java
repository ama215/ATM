/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import java.sql.*;

/**
 *
 * @author Abed AL-Mottaleb
 */
public class DB_connect {
    
    private Connection  con;
    private Statement   st;
    private ResultSet   res;
    
    public DB_connect(){
        
     try {
         
         Class.forName("com.mysql.cj.jdbc.Driver");
         
         con = DriverManager.getConnection("jdbc:mysql://localhost:3306/atm","root","");
         st = con.createStatement();
         
         
         
         
         
         
     }catch(Exception e)
     {
         
     System.out.println(e);
     }
    }
     public void getData () {
         
         try {
             
             String query = "select *from card";
             res = st.executeQuery(query);
             System.out.println("Records are: ");
             while(res.next())
             {
                 
              String card = res.getString("card");
              String acc = res.getString("acc");
              String dep = res.getString("bal");
              
              System.out.println("card: "+ card + " ,acc: "+acc + " ,balance: +" +dep );
              
                 
                 
             }
             
             
             
             
             
         }catch(Exception e) { 
             System.out.println(e);
         }
      
        
        
    }
     
     public boolean DB_lookup(int card,int pin) throws SQLException{
         
       
       //System.out.println(temp);
       String SQL = "SELECT * FROM cards ";
      
       ResultSet res = st.executeQuery(SQL);
       
      // int p_t = res.getStr
       
       boolean b=false;
       
       while(res.next()) {
        //System.out.println(res.getString("ID"));
       // System.out.println(res.getString("pin"));
        if(res.getInt("ID")==card) 
        {// System.out.println(pin);
          if (res.getInt("pin")==pin){
              
              b=true;
              
          }  
          break;
            
        }
           
           
       }

       return b;
     }
}
