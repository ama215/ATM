/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import java.net.*;
import java.io.*;

/**
 *
 * @author Abed AL-Mottaleb
 */
public class wait_connection {
    
    public void server_socket() {
    
        try {
        ServerSocket ss = new ServerSocket(350);
        Socket s = ss.accept();
        DataInputStream s_in = new DataInputStream(s.getInputStream());
        DataOutputStream s_out = new DataOutputStream(s.getOutputStream());
        BufferedReader br = new BufferedReader (new InputStreamReader(System.in));
        
        
      int card = s_in.readInt();
      int pin = s_in.readInt();
        //System.out.println("Client says: ");
        
       DB_connect con = new DB_connect();
       boolean b=false;
       while(!b) {
           
       b=con.DB_lookup(card, pin);
       
       if (b){
           
           System.out.println("Allowed!");
           s_out.writeUTF("Acces allowed! Please choose an account number.");
           s_out.flush();
           
       }
       
       else { 
           System.out.println("Denied!");
           s_out.writeUTF("Acces denied!Please try again.");
           s_out.flush();
           pin = s_in.readInt();
       }
       
      
      
       }
      
       
//     String rec="",sen="";
//     
//     while(!rec.equals("stop"))
//     {
//      rec=s_in.readUTF();
//      System.out.println("Client Says: "+rec);
//      sen=br.readLine();
//      s_out.writeUTF(sen);
//      s_out.flush();
//         
//         
//     }
        
     s.close();
     ss.close();
     s_out.close();
        
        
        }catch(Exception e){System.out.println(e); }
    
    
    
}
    
}
