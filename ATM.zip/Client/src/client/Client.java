/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import java.io.*;
import java.net.*;

/**
 *
 * @author Abed AL-Mottaleb
 */
public class Client {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        
      System.out.println("Please insert a card number");
      BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
      int card = Integer.parseInt(br.readLine());
      System.out.println("Please enter the corresponding pin");
      int pin = Integer.parseInt(br.readLine());  //br.readLine();
      
      call_connection c = new call_connection();
      c.call_server(card,pin);
      
      
      
      
      
 
      
            
            
            
       
        
    }
    
    }
