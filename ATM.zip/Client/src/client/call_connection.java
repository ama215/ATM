/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

/**
 *
 * @author Abed AL-Mottaleb
 */
public class call_connection {
    
    
    public void call_server(int card,int pin) throws IOException {
     try 
       {
           
           Socket s = new Socket("localhost",350);
           DataOutputStream s_out = new DataOutputStream(s.getOutputStream());
           DataInputStream s_in = new DataInputStream(s.getInputStream());
           BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
           
                   
//           s_out.writeUTF("Hello Server, A client is waiting to be served");
//           s_out.flush();
//           String reply = s_in.readUTF();
         //  if (reply=="Welcome") {
            
               
            s_out.writeInt(card);
            s_out.flush();
            s_out.writeInt(pin);
            s_out.flush();
            //String send="",rec="";
            int count=0;
            String rec=s_in.readUTF();
            while(!rec.equals("Acces allowed! Please choose an account number."))
            
            {   
             count =count+1;
            //send = br.readLine();
            System.out.println("Server replies: " + rec);
            System.out.println("Enter new pin:");
            s_out.writeInt(Integer.parseInt(br.readLine()));
            s_out.flush();
            rec=s_in.readUTF();
            
            
                
               
                
                
                
            }
            
            System.out.println("Server replies: " + rec);
            
        
           
       }catch(Exception e){ System.out.println(e); }
     
      //  else {
               
        //       System.out.println("Server not availabe");
            
               
          // }
     
            
    
     
    }
    
    
    }
    

